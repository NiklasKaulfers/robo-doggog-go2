// Copyright 2025 The ODML Authors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef THIRD_PARTY_ODML_LITERT_LITERT_CC_INTERNAL_SCOPED_FILE_WIN_H_
#define THIRD_PARTY_ODML_LITERT_LITERT_CC_INTERNAL_SCOPED_FILE_WIN_H_

#if defined(_WIN32)

#include <Windows.h>
#include <fcntl.h>
#include <io.h>

#include <cctype>
#include <cerrno>
#include <cstddef>
#include <string>

#ifndef LITERT_NO_ABSL
#include "absl/status/status.h"  // from @com_google_absl
#include "absl/status/statusor.h"  // from @com_google_absl
#include "absl/strings/str_cat.h"  // from @com_google_absl
#endif  // LITERT_NO_ABSL
#include "litert/cc/internal/scoped_file.h"

namespace litert {
namespace internal::scoped_file_detail {

inline std::wstring Utf8ToWideChar(StringView utf8str) {
  int size_required = MultiByteToWideChar(CP_UTF8, 0, utf8str.data(),
                                          (int)utf8str.size(), nullptr, 0);
  std::wstring ws_translated_str(size_required, 0);
  MultiByteToWideChar(CP_UTF8, 0, utf8str.data(), (int)utf8str.size(),
                      &ws_translated_str[0], size_required);
  return ws_translated_str;
}

inline ScopedFileStatusOr<ScopedFile> OpenImpl(StringView path,
                                               DWORD file_attribute_flag) {
  std::wstring ws_path = Utf8ToWideChar(path);

  DWORD share_mode = FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE;
  DWORD access = GENERIC_READ;
  if (file_attribute_flag == FILE_ATTRIBUTE_NORMAL) {
    access |= GENERIC_WRITE;
  }
  HANDLE hfile = ::CreateFileW(ws_path.c_str(), access, share_mode, nullptr,
                               OPEN_EXISTING, file_attribute_flag, nullptr);
  if (hfile == INVALID_HANDLE_VALUE) {
#ifndef LITERT_NO_ABSL
    return absl::UnknownError(absl::StrCat("Failed to open: ", path));
#else   // LITERT_NO_ABSL
    return Unexpected(Status::kErrorFileIO,
                      "Failed to open: " + std::string(path));
#endif  // LITERT_NO_ABSL
  }
  return ScopedFile(hfile);
}

inline std::string GetLastErrorString() {
  const DWORD error = GetLastError();
  LPSTR message_buffer = nullptr;
  const DWORD chars_written = FormatMessageA(
      FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM |
          FORMAT_MESSAGE_IGNORE_INSERTS,
      NULL, error, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
      reinterpret_cast<LPSTR>(&message_buffer), 0, NULL);
  if (chars_written > 0 && message_buffer != nullptr) {
    std::string error_message = message_buffer;
    LocalFree(message_buffer);
    while (!error_message.empty() && std::isspace(error_message.back())) {
      error_message.pop_back();
    }
    return error_message;
  }
  return std::to_string(error);
}

}  // namespace internal::scoped_file_detail

inline const HANDLE ScopedFile::kInvalidPlatformFile = INVALID_HANDLE_VALUE;

inline ScopedFileStatusOr<ScopedFile> ScopedFile::Open(StringView path) {
  return internal::scoped_file_detail::OpenImpl(path, FILE_ATTRIBUTE_READONLY);
}

inline ScopedFileStatusOr<ScopedFile> ScopedFile::OpenWritable(
    StringView path) {
  return internal::scoped_file_detail::OpenImpl(path, FILE_ATTRIBUTE_NORMAL);
}

inline void ScopedFile::CloseFile(HANDLE file) { ::CloseHandle(file); }

inline ScopedFileStatusOr<size_t> ScopedFile::GetSizeImpl(HANDLE file) {
  LARGE_INTEGER size;
  if (!::GetFileSizeEx(file, &size)) {
#ifndef LITERT_NO_ABSL
    return absl::UnknownError("Failed to get file size");
#else   // LITERT_NO_ABSL
    return Unexpected(Status::kErrorFileIO, "Failed to get file size");
#endif  // LITERT_NO_ABSL
  }
  return static_cast<size_t>(size.QuadPart);
}

inline ScopedFileStatusOr<ScopedFile> ScopedFile::Duplicate() {
  if (!IsValid()) {
#ifndef LITERT_NO_ABSL
    return absl::InvalidArgumentError("File is not opened.");
#else   // LITERT_NO_ABSL
    return Unexpected(Status::kErrorInvalidArgument, "File is not opened.");
#endif  // LITERT_NO_ABSL
  }
  HANDLE duplicated;
  if (!DuplicateHandle(GetCurrentProcess(), file_, GetCurrentProcess(),
                       &duplicated, 0, FALSE, DUPLICATE_SAME_ACCESS)) {
#ifndef LITERT_NO_ABSL
    return absl::FailedPreconditionError(
        "Could not duplicate handle: " +
        internal::scoped_file_detail::GetLastErrorString());
#else   // LITERT_NO_ABSL
    return Unexpected(Status::kErrorFileIO,
                      "Could not duplicate handle: " +
                          internal::scoped_file_detail::GetLastErrorString());
#endif  // LITERT_NO_ABSL
  }
  return ScopedFile(duplicated);
}

inline ScopedFileStatusOr<int> ScopedFile::Release() {
  if (!IsValid()) {
#ifndef LITERT_NO_ABSL
    return absl::InvalidArgumentError("File is not opened.");
#else   // LITERT_NO_ABSL
    return Unexpected(Status::kErrorInvalidArgument, "File is not opened.");
#endif  // LITERT_NO_ABSL
  }

  char buffer[1];
  if (!ReadFile(file_, &buffer, /*nNumberOfBytesToRead=*/0,
                /*lpNumberOfBytesRead=*/nullptr, /*lpOverlapped=*/nullptr)) {
#ifndef LITERT_NO_ABSL
    return absl::FailedPreconditionError(
        "Could not convert asynchronous handle to C file descriptor: " +
        internal::scoped_file_detail::GetLastErrorString());
#else   // LITERT_NO_ABSL
    return Unexpected(Status::kErrorFileIO,
                      "Could not convert asynchronous handle to C file "
                      "descriptor: " +
                          internal::scoped_file_detail::GetLastErrorString());
#endif  // LITERT_NO_ABSL
  }

  const int fd = _open_osfhandle(reinterpret_cast<intptr_t>(file_),
                                 /*flags=*/_O_RDWR | _O_BINARY);
  if (fd < 0) {
#ifndef LITERT_NO_ABSL
    return absl::ErrnoToStatus(
        errno, "Could not convert HANDLE to a C file descriptor");
#else   // LITERT_NO_ABSL
    return Unexpected(Status::kErrorFileIO,
                      "Could not convert HANDLE to a C file descriptor");
#endif  // LITERT_NO_ABSL
  }
  ReleasePlatformFile();
  return fd;
}

}  // namespace litert

#endif  // defined(_WIN32)

#endif  // THIRD_PARTY_ODML_LITERT_LITERT_CC_INTERNAL_SCOPED_FILE_WIN_H_
